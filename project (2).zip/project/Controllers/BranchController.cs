using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using project.Model;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BranchController : ControllerBase
    {
        private readonly IndiancargosystemContext _context;

        public BranchController(IndiancargosystemContext context)
        {
            _context = context;
        }

        // GET: api/Branch
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BranchDetail>>> GetBranchDetails()
        {
            return await _context.BranchDetails.ToListAsync();
        }

        // GET: api/Branch/5
        [HttpGet("{id}")]
        public async Task<ActionResult<BranchDetail>> GetBranchDetail(string id)
        {
            var branchDetail = await _context.BranchDetails.FindAsync(id);

            if (branchDetail == null)
            {
                return NotFound();
            }

            return branchDetail;
        }

        // PUT: api/Branch/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBranchDetail(string id, BranchDetail branchDetail)
        {
            if (id != branchDetail.BranchId)
            {
                return BadRequest();
            }

            _context.Entry(branchDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BranchDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Branch
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<BranchDetail>> PostBranchDetail(BranchDetail branchDetail)
        {
            _context.BranchDetails.Add(branchDetail);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (BranchDetailExists(branchDetail.BranchId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetBranchDetail", new { id = branchDetail.BranchId }, branchDetail);
        }

        // DELETE: api/Branch/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBranchDetail(string id)
        {
            var branchDetail = await _context.BranchDetails.FindAsync(id);
            if (branchDetail == null)
            {
                return NotFound();
            }

            _context.BranchDetails.Remove(branchDetail);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool BranchDetailExists(string id)
        {
            return _context.BranchDetails.Any(e => e.BranchId == id);
        }
    }
}
