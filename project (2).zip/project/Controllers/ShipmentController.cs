using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using project.Model;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShipmentController : ControllerBase
    {
        private readonly IndiancargosystemContext _context;

        public ShipmentController(IndiancargosystemContext context)
        {
            _context = context;
        }

        // GET: api/Shipment
        [HttpGet]
        public async Task<ActionResult<IEnumerable<IndianCargoShipment>>> GetIndianCargoShipments()
        {
            return await _context.IndianCargoShipments.ToListAsync();
        }

        // GET: api/Shipment/5
        [HttpGet("{id}")]
        public async Task<ActionResult<IndianCargoShipment>> GetIndianCargoShipment(string id)
        {
            var indianCargoShipment = await _context.IndianCargoShipments.FindAsync(id);

            if (indianCargoShipment == null)
            {
                return NotFound();
            }

            return indianCargoShipment;
        }

        // PUT: api/Shipment/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutIndianCargoShipment(string id, IndianCargoShipment indianCargoShipment)
        {
            if (id != indianCargoShipment.Id)
            {
                return BadRequest();
            }

            _context.Entry(indianCargoShipment).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!IndianCargoShipmentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Shipment
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<IndianCargoShipment>> PostIndianCargoShipment(IndianCargoShipment indianCargoShipment)
        {
            _context.IndianCargoShipments.Add(indianCargoShipment);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (IndianCargoShipmentExists(indianCargoShipment.Id))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetIndianCargoShipment", new { id = indianCargoShipment.Id }, indianCargoShipment);
        }

        // DELETE: api/Shipment/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteIndianCargoShipment(string id)
        {
            var indianCargoShipment = await _context.IndianCargoShipments.FindAsync(id);
            if (indianCargoShipment == null)
            {
                return NotFound();
            }

            _context.IndianCargoShipments.Remove(indianCargoShipment);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool IndianCargoShipmentExists(string id)
        {
            return _context.IndianCargoShipments.Any(e => e.Id == id);
        }
    }
}
