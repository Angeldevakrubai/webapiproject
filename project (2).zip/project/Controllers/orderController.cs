using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using project.Model;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class orderController : ControllerBase
    {
        private readonly IndiancargosystemContext _context;

        public orderController(IndiancargosystemContext context)
        {
            _context = context;
        }

        // GET: api/order
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Orderstatus>>> GetOrderstatuses()
        {
            return await _context.Orderstatuses.ToListAsync();
        }

        // GET: api/order/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Orderstatus>> GetOrderstatus(string id)
        {
            var orderstatus = await _context.Orderstatuses.FindAsync(id);

            if (orderstatus == null)
            {
                return NotFound();
            }

            return orderstatus;
        }

        // PUT: api/order/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutOrderstatus(string id, Orderstatus orderstatus)
        {
            if (id != orderstatus.ProductId)
            {
                return BadRequest();
            }

            _context.Entry(orderstatus).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrderstatusExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/order
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Orderstatus>> PostOrderstatus(Orderstatus orderstatus)
        {
            _context.Orderstatuses.Add(orderstatus);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (OrderstatusExists(orderstatus.ProductId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetOrderstatus", new { id = orderstatus.ProductId }, orderstatus);
        }

        // DELETE: api/order/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteOrderstatus(string id)
        {
            var orderstatus = await _context.Orderstatuses.FindAsync(id);
            if (orderstatus == null)
            {
                return NotFound();
            }

            _context.Orderstatuses.Remove(orderstatus);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool OrderstatusExists(string id)
        {
            return _context.Orderstatuses.Any(e => e.ProductId == id);
        }
    }
}
