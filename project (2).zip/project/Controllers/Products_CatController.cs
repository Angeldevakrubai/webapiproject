using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using project.Model;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Products_CatController : ControllerBase
    {
        private readonly IndiancargosystemContext _context;

        public Products_CatController(IndiancargosystemContext context)
        {
            _context = context;
        }

        // GET: api/Products_Cat
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductsCategory>>> GetProductsCategories()
        {
            return await _context.ProductsCategories.ToListAsync();
        }

        // GET: api/Products_Cat/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ProductsCategory>> GetProductsCategory(string id)
        {
            var productsCategory = await _context.ProductsCategories.FindAsync(id);

            if (productsCategory == null)
            {
                return NotFound();
            }

            return productsCategory;
        }

        // PUT: api/Products_Cat/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProductsCategory(string id, ProductsCategory productsCategory)
        {
            if (id != productsCategory.ProductId)
            {
                return BadRequest();
            }

            _context.Entry(productsCategory).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductsCategoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Products_Cat
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<ProductsCategory>> PostProductsCategory(ProductsCategory productsCategory)
        {
            _context.ProductsCategories.Add(productsCategory);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (ProductsCategoryExists(productsCategory.ProductId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetProductsCategory", new { id = productsCategory.ProductId }, productsCategory);
        }

        // DELETE: api/Products_Cat/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProductsCategory(string id)
        {
            var productsCategory = await _context.ProductsCategories.FindAsync(id);
            if (productsCategory == null)
            {
                return NotFound();
            }

            _context.ProductsCategories.Remove(productsCategory);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ProductsCategoryExists(string id)
        {
            return _context.ProductsCategories.Any(e => e.ProductId == id);
        }
    }
}
