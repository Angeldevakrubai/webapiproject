using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using project.Model;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DistributorController : ControllerBase
    {
        private readonly IndiancargosystemContext _context;

        public DistributorController(IndiancargosystemContext context)
        {
            _context = context;
        }

        // GET: api/Distributor
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DistributorInfo>>> GetDistributorInfos()
        {
            return await _context.DistributorInfos.ToListAsync();
        }

        // GET: api/Distributor/5
        [HttpGet("{id}")]
        public async Task<ActionResult<DistributorInfo>> GetDistributorInfo(string id)
        {
            var distributorInfo = await _context.DistributorInfos.FindAsync(id);

            if (distributorInfo == null)
            {
                return NotFound();
            }

            return distributorInfo;
        }

        // PUT: api/Distributor/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutDistributorInfo(string id, DistributorInfo distributorInfo)
        {
            if (id != distributorInfo.DistId)
            {
                return BadRequest();
            }

            _context.Entry(distributorInfo).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DistributorInfoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Distributor
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<DistributorInfo>> PostDistributorInfo(DistributorInfo distributorInfo)
        {
            _context.DistributorInfos.Add(distributorInfo);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (DistributorInfoExists(distributorInfo.DistId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetDistributorInfo", new { id = distributorInfo.DistId }, distributorInfo);
        }

        // DELETE: api/Distributor/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDistributorInfo(string id)
        {
            var distributorInfo = await _context.DistributorInfos.FindAsync(id);
            if (distributorInfo == null)
            {
                return NotFound();
            }

            _context.DistributorInfos.Remove(distributorInfo);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool DistributorInfoExists(string id)
        {
            return _context.DistributorInfos.Any(e => e.DistId == id);
        }
    }
}
