using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using project.Model;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Products_DetController : ControllerBase
    {
        private readonly IndiancargosystemContext _context;

        public Products_DetController(IndiancargosystemContext context)
        {
            _context = context;
        }

        // GET: api/Products_Det
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductsDetail>>> GetProductsDetails()
        {
            return await _context.ProductsDetails.ToListAsync();
        }

        // GET: api/Products_Det/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ProductsDetail>> GetProductsDetail(string id)
        {
            var productsDetail = await _context.ProductsDetails.FindAsync(id);

            if (productsDetail == null)
            {
                return NotFound();
            }

            return productsDetail;
        }

        // PUT: api/Products_Det/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProductsDetail(string id, ProductsDetail productsDetail)
        {
            if (id != productsDetail.ProductId)
            {
                return BadRequest();
            }

            _context.Entry(productsDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductsDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Products_Det
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<ProductsDetail>> PostProductsDetail(ProductsDetail productsDetail)
        {
            _context.ProductsDetails.Add(productsDetail);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (ProductsDetailExists(productsDetail.ProductId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetProductsDetail", new { id = productsDetail.ProductId }, productsDetail);
        }

        // DELETE: api/Products_Det/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProductsDetail(string id)
        {
            var productsDetail = await _context.ProductsDetails.FindAsync(id);
            if (productsDetail == null)
            {
                return NotFound();
            }

            _context.ProductsDetails.Remove(productsDetail);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ProductsDetailExists(string id)
        {
            return _context.ProductsDetails.Any(e => e.ProductId == id);
        }
    }
}
