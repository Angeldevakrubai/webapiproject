using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using project.Model;

namespace project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly IndiancargosystemContext _context;

        public CustomerController(IndiancargosystemContext context)
        {
            _context = context;
        }

        // GET: api/Customer
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CustomerInformation>>> GetCustomerInformations()
        {
            return await _context.CustomerInformations.ToListAsync();
        }

        // GET: api/Customer/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CustomerInformation>> GetCustomerInformation(string id)
        {
            var customerInformation = await _context.CustomerInformations.FindAsync(id);

            if (customerInformation == null)
            {
                return NotFound();
            }

            return customerInformation;
        }

        // PUT: api/Customer/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCustomerInformation(string id, CustomerInformation customerInformation)
        {
            if (id != customerInformation.CustId)
            {
                return BadRequest();
            }

            _context.Entry(customerInformation).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CustomerInformationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Customer
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<CustomerInformation>> PostCustomerInformation(CustomerInformation customerInformation)
        {
            _context.CustomerInformations.Add(customerInformation);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (CustomerInformationExists(customerInformation.CustId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetCustomerInformation", new { id = customerInformation.CustId }, customerInformation);
        }

        // DELETE: api/Customer/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCustomerInformation(string id)
        {
            var customerInformation = await _context.CustomerInformations.FindAsync(id);
            if (customerInformation == null)
            {
                return NotFound();
            }

            _context.CustomerInformations.Remove(customerInformation);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CustomerInformationExists(string id)
        {
            return _context.CustomerInformations.Any(e => e.CustId == id);
        }
    }
}
