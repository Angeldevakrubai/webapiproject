﻿using System;
using System.Collections.Generic;

#nullable disable

namespace project.Model
{
    public partial class BranchDetail
    {
        public string BranchId { get; set; }
        public string BranchName { get; set; }
        public string BranchLocation { get; set; }
    }
}
