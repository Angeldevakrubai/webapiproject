﻿using System;
using System.Collections.Generic;

#nullable disable

namespace project.Model
{
    public partial class IndianCargoShipment
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string PhoneNo { get; set; }
    }
}
