﻿using System;
using System.Collections.Generic;

#nullable disable

namespace project.Model
{
    public partial class CustomerInformation
    {
        public string CustId { get; set; }
        public string CustName { get; set; }
        public string CustPhnNo { get; set; }
        public string CustEmail { get; set; }
        public string CustLocation { get; set; }
    }
}
