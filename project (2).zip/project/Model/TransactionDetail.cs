﻿using System;
using System.Collections.Generic;

#nullable disable

namespace project.Model
{
    public partial class TransactionDetail
    {
        public string CustId { get; set; }
        public string ProductId { get; set; }
        public decimal? NoOfTransactions { get; set; }
        public decimal? TransactionAmount { get; set; }
    }
}
