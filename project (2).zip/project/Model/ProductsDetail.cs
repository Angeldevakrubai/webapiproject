﻿using System;
using System.Collections.Generic;

#nullable disable

namespace project.Model
{
    public partial class ProductsDetail
    {
        public string ProductId { get; set; }
        public string ProductName { get; set; }
    }
}
