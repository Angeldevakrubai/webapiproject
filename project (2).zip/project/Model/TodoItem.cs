﻿using System;
using System.Collections.Generic;

#nullable disable

namespace project.Model
{
    public partial class TodoItem
    {
        public string Id { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddress { get; set; }
        public string CustomerPhoneNo { get; set; }
    }
}
