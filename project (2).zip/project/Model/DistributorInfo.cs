﻿using System;
using System.Collections.Generic;

#nullable disable

namespace project.Model
{
    public partial class DistributorInfo
    {
        public string DistId { get; set; }
        public string DistName { get; set; }
        public string DistLocation { get; set; }
    }
}
