﻿using System;
using System.Collections.Generic;

#nullable disable

namespace project.Model
{
    public partial class ProductsCategory
    {
        public string ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductAvailability { get; set; }
    }
}
