﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace project.Model
{
    public partial class IndiancargosystemContext : DbContext
    {
        public IndiancargosystemContext()
        {
        }

        public IndiancargosystemContext(DbContextOptions<IndiancargosystemContext> options)
            : base(options)
        {
        }

        public virtual DbSet<BoardingType> BoardingTypes { get; set; }
        public virtual DbSet<BranchDetail> BranchDetails { get; set; }
        public virtual DbSet<CustomerInformation> CustomerInformations { get; set; }
        public virtual DbSet<DistributorInfo> DistributorInfos { get; set; }
        public virtual DbSet<IndianCargoShipment> IndianCargoShipments { get; set; }
        public virtual DbSet<Orderstatus> Orderstatuses { get; set; }
        public virtual DbSet<ProductsCategory> ProductsCategories { get; set; }
        public virtual DbSet<ProductsDetail> ProductsDetails { get; set; }
        public virtual DbSet<TodoItem> TodoItems { get; set; }
        public virtual DbSet<TransactionDetail> TransactionDetails { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=.\\SQLEXPRESS;Database=Indian-cargo-system;User ID=sa;Password=pass@123;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BoardingType>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Boarding_Type");

                entity.Property(e => e.NationalVsInternational)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("National_VS_International");
            });

            modelBuilder.Entity<BranchDetail>(entity =>
            {
                entity.HasKey(e => e.BranchId)
                    .HasName("Branch_Details_Id_pk");

                entity.ToTable("Branch_Details");

                entity.Property(e => e.BranchId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Branch_Id");

                entity.Property(e => e.BranchLocation)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Branch_Location");

                entity.Property(e => e.BranchName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Branch_Name");
            });

            modelBuilder.Entity<CustomerInformation>(entity =>
            {
                entity.HasKey(e => e.CustId)
                    .HasName("Customer_Information_cust_Id_pk");

                entity.ToTable("Customer_Information");

                entity.Property(e => e.CustId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("cust_Id");

                entity.Property(e => e.CustEmail)
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("cust_email");

                entity.Property(e => e.CustLocation)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("cust_location");

                entity.Property(e => e.CustName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("cust_name");

                entity.Property(e => e.CustPhnNo)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("cust_phn_no");
            });

            modelBuilder.Entity<DistributorInfo>(entity =>
            {
                entity.HasKey(e => e.DistId)
                    .HasName("Dsitributor_info_Id_pk");

                entity.ToTable("Distributor_info");

                entity.Property(e => e.DistId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Dist_Id");

                entity.Property(e => e.DistLocation)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Dist_Location");

                entity.Property(e => e.DistName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Dist_Name");
            });

            modelBuilder.Entity<IndianCargoShipment>(entity =>
            {
                entity.ToTable("Indian_Cargo_Shipment");

                entity.Property(e => e.Id)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Address)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNo)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("Phone No");
            });

            modelBuilder.Entity<Orderstatus>(entity =>
            {
                entity.HasKey(e => e.ProductId)
                    .HasName("PK__ordersta__9834FBBA217E7323");

                entity.ToTable("orderstatus");

                entity.Property(e => e.ProductId)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("Product_Id");

                entity.Property(e => e.Deliverydate)
                    .HasColumnType("date")
                    .HasColumnName("deliverydate");

                entity.Property(e => e.Orderamount).HasColumnName("orderamount");

                entity.Property(e => e.Orderdate)
                    .HasColumnType("date")
                    .HasColumnName("orderdate");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("Product_name");
            });

            modelBuilder.Entity<ProductsCategory>(entity =>
            {
                entity.HasKey(e => e.ProductId)
                    .HasName("Products_Category_Id_pk");

                entity.ToTable("Products_Category");

                entity.Property(e => e.ProductId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Product_Id");

                entity.Property(e => e.ProductAvailability)
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("Product_Availability");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Product_Name");
            });

            modelBuilder.Entity<ProductsDetail>(entity =>
            {
                entity.HasKey(e => e.ProductId)
                    .HasName("Products_Details_Id_pk");

                entity.ToTable("Products_Details");

                entity.Property(e => e.ProductId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Product_Id");

                entity.Property(e => e.ProductName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Product_Name");
            });

            modelBuilder.Entity<TodoItem>(entity =>
            {
                entity.ToTable("TodoItem");

                entity.Property(e => e.Id)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Id ");

                entity.Property(e => e.CustomerAddress)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("Customer_Address");

                entity.Property(e => e.CustomerName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Customer_Name");

                entity.Property(e => e.CustomerPhoneNo)
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("Customer_PhoneNo");
            });

            modelBuilder.Entity<TransactionDetail>(entity =>
            {
                entity.HasKey(e => e.CustId)
                    .HasName("Transaction_Details_Id_pk");

                entity.ToTable("Transaction_Details");

                entity.Property(e => e.CustId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Cust_Id");

                entity.Property(e => e.NoOfTransactions)
                    .HasColumnType("decimal(38, 0)")
                    .HasColumnName("No_Of_Transactions");

                entity.Property(e => e.ProductId)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Product_Id");

                entity.Property(e => e.TransactionAmount)
                    .HasColumnType("decimal(38, 0)")
                    .HasColumnName("Transaction_Amount");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
