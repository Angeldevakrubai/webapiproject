﻿using System;
using System.Collections.Generic;

#nullable disable

namespace project.Model
{
    public partial class Orderstatus
    {
        public string ProductId { get; set; }
        public string ProductName { get; set; }
        public DateTime Orderdate { get; set; }
        public int Orderamount { get; set; }
        public DateTime Deliverydate { get; set; }
    }
}
