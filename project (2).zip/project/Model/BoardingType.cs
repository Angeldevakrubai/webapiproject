﻿using System;
using System.Collections.Generic;

#nullable disable

namespace project.Model
{
    public partial class BoardingType
    {
        public string NationalVsInternational { get; set; }
    }
}
